Bug Tanks

Installation:
Run Bug Tanks.msi and follow the installer instructions.
Note that DirectX 10 is required.

Controls:
WASD for steering, Space for shooting, Q and E to turn your turret, N and M to rotate your camera.